<!DOCTYPE html>
<html>
<body>
    

<?php


$message = $_POST['message'];


?>

</body>
</html>